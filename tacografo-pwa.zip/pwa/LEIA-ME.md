# Tacógrafo PWA — como instalar no telemóvel

A pasta contém a app pronta a publicar:
`index.html` · `manifest.webmanifest` · `sw.js` · `icon-192.png` · `icon-512.png`

Para o ícone e o modo offline funcionarem, os navegadores exigem que a app
esteja num endereço **https**. O caminho grátis mais simples é o GitHub Pages:

## Publicar no GitHub Pages (uma vez, ~5 min)

1. Cria conta em **github.com** (se ainda não tiveres)
2. Botão **+** → **New repository** → nome: `tacografo` → **Create repository**
3. Na página do repositório: **uploading an existing file** → arrasta os 5 ficheiros desta pasta → **Commit changes**
4. **Settings** → **Pages** → em *Branch* escolhe **main** e **/ (root)** → **Save**
5. Passado ~1 minuto, a app fica em:
   `https://O-TEU-UTILIZADOR.github.io/tacografo/`

## Instalar no telemóvel

- **Android (Chrome):** abre o endereço → menu ⋮ → **Instalar aplicação**
- **iPhone (Safari):** abre o endereço → botão Partilhar → **Adicionar ao ecrã principal**

A partir daí abre pelo ícone, funciona **sem internet** (os ficheiros .ddd/.esm
são sempre lidos localmente — nada é enviado para lado nenhum). A exportação
PDF/Excel precisa de internet só na primeira utilização; depois fica em cache.

## Atualizar a app

Substitui o `index.html` no repositório por uma versão nova e muda `tacografo-v1`
para `tacografo-v2` no `sw.js`, para o telemóvel apanhar a atualização.
